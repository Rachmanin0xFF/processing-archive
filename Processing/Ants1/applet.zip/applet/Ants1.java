import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Ants1 extends PApplet {

class Ant {
  float x;
  float y;
  float angle;
  int index;
  boolean off;
  int myCol;
  int count;
  public Ant(float x, float y, float angle, int index, int myCol, int count) {
    this.x = x;
    this.y = y;
    this.angle = angle;
    this.index = index;
    this.myCol = myCol;
    this.count = count;
  }
  public void update() {
    count++;
    if(red(get((int)x, (int)y)) != 255)
      off = true;
    if(!off) {
      stroke(myCol);
      point(x, y);
      x += cos(angle);
      y += sin(angle);
      if(random(100)>97) {
        int newCol = myCol;
        float newAngle = PI/2 + angle;
        if(random(100)>50) {
          newAngle = -PI/2 + angle;
        }
        Ants.add(new Ant(x+cos(newAngle), y+sin(newAngle), newAngle, Ants.size(), newCol, count));
      }
    }
  }
}
ArrayList<Ant> Ants = new ArrayList<Ant>();
public void setup() {
  size(768, 512, P2D);
  background(255);
  smooth();
  stroke(0);
}
public void draw() {
  for(int i = 0; i < Ants.size(); i++) {
    Ants.get(i).update();
  }
}
public void mousePressed() {
  Ants.add(new Ant(mouseX, mouseY, -PI/2, Ants.size(), color(0, 0, 0), 0));
}
public void keyPressed() {
  background(255);
  Ants.clear();
}
public int r(int c){return (c>>16)&255;}
public int g(int c){return (c>>8)&255;}
public int b(int c){return c&255;}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "Ants1" });
  }
}
