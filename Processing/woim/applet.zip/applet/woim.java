import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class woim extends PApplet {

//Dedicated to my Dad.
float mdp, k, emdp, t = 0;
boolean mau, wmau;
public void setup() {
  size(768, 512);
  stroke(255);
  strokeWeight(1);
  smooth();
  colorMode(HSB);
  mau = true;
}
public void draw() {
    if(mousePressed) { if(!wmau) mau = !mau; wmau = true; t = 0; } else wmau = false;
    if(keyPressed&&mau) frameRate(9); else frameRate(60);
  background(0);
  for(int i = 0; i < 1; i++)
    recu(mouseX-width/2, mouseY-height/2, 700+i, mouseX-width/2, mouseY-height/2);
  t++;
  k = 10+sin(t/300+emdp/30)*5;
  mdp = dist(mouseX, mouseY, pmouseX, pmouseY);
  emdp += mdp;
  emdp /= 1.1f;
}
//It's all one line :P
public void recu(int x, int y, float id, float px, float py) {
  if(!mau) point(x+width/2, y+height/2); else
  line(x+width/2, y+height/2, px+width/2, py+height/2);
  float r = 0; if(mau) r = id*id*sin(t/50000); else r = id;
  int nx = PApplet.parseInt(x+k*sin(r)*mix(1, 4*sin((id+t/10)/30), 0.1f));
  int ny = PApplet.parseInt(y+k*cos(r)*mix(1, 4*sin((id+t/10)/30), 0.1f));
    if(id>0) recu(nx, ny, id-0.7f, x, y);
}
public float mix(float x, float y, float a) { return x*(1-a)+y*a; }
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "woim" });
  }
}
