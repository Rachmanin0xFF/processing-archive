import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class BennyTweek extends PApplet {

/* OpenProcessing Tweak of *@*http://www.openprocessing.org/sketch/93379*@* */
/* !do not delete the line above, required for linking your tweak if you re-upload */
float[] x = new float[100];
float[] y = new float[100];
float f;
float gx;
float gy;

public void setup() {
  size(712, 712);
  stroke(255);
  background(0);
}

public void draw() {
  x[x.length-1] = mouseX;
  y[y.length-1] = mouseY;
  if(!mousePressed) {
  for(int i = 1; i < x.length-1; i++) {
    float dx = x[i+1] - x[i];
    float dy = y[i+1] - y[i];
    float angle = atan2(dy, dx) + 0.1f;
    x[i] = x[i+1] - (cos(angle + (noise(y[i]/70, x[i]/70, f) - 0.5f)/1));
    y[i] = y[i+1] - (sin(angle + (noise(x[i]/70, y[i]/70, f) - 0.5f)/1));
  }
  line(x[1], y[1], x[2], y[2]);
  } else {
    background(0);
    for(int i = 0; i < x.length-1; i++) {
      x[i] = mouseX+random(0.1f);
      y[i] = mouseY+random(0.1f);
    }
    gx = mouseX;
    gy = mouseY;
  }
  f += 0.01f;
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "BennyTweek" });
  }
}
